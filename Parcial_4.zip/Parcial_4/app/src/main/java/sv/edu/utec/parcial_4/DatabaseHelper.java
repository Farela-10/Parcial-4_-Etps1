package sv.edu.utec.parcial_4;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "mydatabase.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Crear la tabla "clientes"
        db.execSQL("CREATE TABLE clientes (" +
                "id_cliente INTEGER PRIMARY KEY," +
                "sNombreCliente TEXT," +
                "sApellidosClientes TEXT," +
                "sDireccionCliente TEXT," +
                "sCiudadCliente TEXT" +
                ");");

        // Crear la tabla "MD_Vehiculos"
        db.execSQL("CREATE TABLE MD_Vehiculos (" +
                "ID_Vehiculo INTEGER PRIMARY KEY," +
                "sMarca TEXT," +
                "sModelo TEXT" +
                ");");

        // Crear la tabla "MD_ClienteVehiculo"
        db.execSQL("CREATE TABLE MD_ClienteVehiculo (" +
                "ID_Cliente INTEGER," +
                "ID_Vehiculo INTEGER," +
                "sMatricula TEXT," +
                "iKilometros INTEGER," +
                "FOREIGN KEY (ID_Cliente) REFERENCES clientes (id_cliente)," +
                "FOREIGN KEY (ID_Vehiculo) REFERENCES MD_Vehiculos (ID_Vehiculo)" +
                ");");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Si se necesita realizar alguna actualización en la base de datos, se implementa aquí
    }
}
