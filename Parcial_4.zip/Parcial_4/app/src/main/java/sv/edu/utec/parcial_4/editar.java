package sv.edu.utec.parcial_4;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditarActivity extends AppCompatActivity {
    private EditText etNombre;
    private EditText etApellido;
    private EditText etDireccion;
    private EditText etCiudad;
    private Button btnGuardar;

    private DatabaseHelper databaseHelper;
    private SQLiteDatabase database;
    private Registro registro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar);

        // Obtener el registro pasado desde MainActivity
        Intent intent = getIntent();
        registro = (Registro) intent.getSerializableExtra("registro");

        // Inicializar la base de datos
        databaseHelper = new DatabaseHelper(this);
        database = databaseHelper.getWritableDatabase();

        // Obtener referencias a los elementos de la interfaz
        etNombre = findViewById(R.id.etNombre);
        etApellido = findViewById(R.id.etApellido);
        etDireccion = findViewById(R.id.etDireccion);
        etCiudad = findViewById(R.id.etCiudad);
        btnGuardar = findViewById(R.id.btnGuardar);

        // Mostrar los datos del registro en los campos de texto
        etNombre.setText(registro.getNombre());
        etApellido.setText(registro.getApellido());
        etDireccion.setText(registro.getDireccion());
        etCiudad.setText(registro.getCiudad());

        // Definir el evento de clic del botón "Guardar"
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener los nuevos valores de los campos de texto
                String nombre = etNombre.getText().toString().trim();
                String apellido = etApellido.getText().toString().trim();
                String direccion = etDireccion.getText().toString().trim();
                String ciudad = etCiudad.getText().toString().trim();

                // Actualizar el registro en la base de datos
                actualizarRegistro(nombre, apellido, direccion, ciudad);

                // Mostrar un mensaje de éxito
                Toast.makeText(EditarActivity.this, "Registro actualizado correctamente", Toast.LENGTH_SHORT).show();

                // Volver a la actividad principal
                Intent intent = new Intent(EditarActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void actualizarRegistro(String nombre, String apellido, String direccion, String ciudad) {
        // Actualizar los valores del registro en la base de datos
        ContentValues values = new ContentValues();
        values.put("sNombreCliente", nombre);
        values.put("sApellidosClientes", apellido);
        values.put("sDireccionCliente", direccion);
        values.put("sCiudadCliente", ciudad);

        String whereClause = "id_cliente=?";
        String[] whereArgs = {String.valueOf(registro.getIdCliente())};

        database.update("clientes", values, whereClause, whereArgs);
    }
}

