package sv.edu.utec.parcial_4;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegistroActivity extends AppCompatActivity {
    private EditText etNombre;
    private EditText etApellido;
    private EditText etDireccion;
    private EditText etCiudad;
    private Button btnRegistrar;

    private DatabaseHelper databaseHelper;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        // Inicializar la base de datos
        databaseHelper = new DatabaseHelper(this);
        database = databaseHelper.getWritableDatabase();

        // Obtener referencias a los elementos de la interfaz
        etNombre = findViewById(R.id.etNombre);
        etApellido = findViewById(R.id.etApellido);
        etDireccion = findViewById(R.id.etDireccion);
        etCiudad = findViewById(R.id.etCiudad);
        btnRegistrar = findViewById(R.id.btnRegistrar);

        // Definir el evento de clic del botón "Registrar"
        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener los valores de los campos de texto
                String nombre = etNombre.getText().toString().trim();
                String apellido = etApellido.getText().toString().trim();
                String direccion = etDireccion.getText().toString().trim();
                String ciudad = etCiudad.getText().toString().trim();

                // Validar que se ingresen todos los datos
                if (nombre.isEmpty() || apellido.isEmpty() || direccion.isEmpty() || ciudad.isEmpty()) {
                    Toast.makeText(RegistroActivity.this, "Por favor, ingresa todos los datos", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Registrar el nuevo cliente en la base de datos
                registrarCliente(nombre, apellido, direccion, ciudad);

                // Mostrar un mensaje de éxito
                Toast.makeText(RegistroActivity.this, "Cliente registrado correctamente", Toast.LENGTH_SHORT).show();

                // Limpiar los campos de texto
                etNombre.setText("");
                etApellido.setText("");
                etDireccion.setText("");
                etCiudad.setText("");
            }
        });
    }

    private void registrarCliente(String nombre, String apellido, String direccion, String ciudad) {
        // Insertar el nuevo cliente en la base de datos
        ContentValues values = new ContentValues();
        values.put("sNombreCliente", nombre);
        values.put("sApellidosClientes", apellido);
        values.put("sDireccionCliente", direccion);
        values.put("sCiudadCliente", ciudad);

        database.insert("clientes", null, values);
    }
}

