package sv.edu.utec.parcial_4;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private SQLiteDatabase database;
    private ListView listViewRegistros;
    private Button btnEliminar;
    private Button btnEditar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar la base de datos
        databaseHelper = new DatabaseHelper(this);
        database = databaseHelper.getWritableDatabase();

        // Obtener referencias a los elementos de la interfaz
        listViewRegistros = findViewById(R.id.listViewRegistros);
        btnEliminar = findViewById(R.id.btnEliminar);
        btnEditar = findViewById(R.id.btnEditar);

        // Cargar los registros en la lista
        cargarRegistros();

        // Definir el evento de clic del botón "Eliminar Registro"
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener el registro seleccionado en la lista
                Registro registroSeleccionado = (Registro) listViewRegistros.getSelectedItem();

                if (registroSeleccionado != null) {
                    // Eliminar el registro de la base de datos
                    eliminarRegistro(registroSeleccionado);
                    // Volver a cargar los registros en la lista
                    cargarRegistros();
                } else {
                    Toast.makeText(MainActivity.this, "Selecciona un registro para eliminar", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Definir el evento de clic del botón "Editar Registro"
        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener el registro seleccionado en la lista
                Registro registroSeleccionado = (Registro) listViewRegistros.getSelectedItem();

                if (registroSeleccionado != null) {
                    // Abrir la actividad de edición y pasar el registro seleccionado
                    Intent intent = new Intent(MainActivity.this, editar.class);
                    intent.putExtra("registro", registroSeleccionado);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Selecciona un registro para editar", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void cargarRegistros() {
        // Obtener los registros de la base de datos
        List<Registro> registros = obtenerRegistros();

        // Crear un adaptador personalizado para la lista de registros
        RegistroAdapter adapter = new RegistroAdapter(this, registros);

        // Asignar el adaptador a la lista
        listViewRegistros.setAdapter((ListAdapter) adapter);
    }

    private List<Registro> obtenerRegistros() {
        // Consultar los registros de la base de datos
        List<Registro> registros = new ArrayList<>();

        Cursor cursor = database.query("clientes", null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                int idCliente = cursor.getInt(cursor.getColumnIndex("id_cliente"));
                String nombre = cursor.getString(cursor.getColumnIndex("sNombreCliente"));
                String apellido = cursor.getString(cursor.getColumnIndex("sApellidosClientes"));
                String direccion = cursor.getString(cursor.getColumnIndex("sDireccionCliente"));
                String ciudad = cursor.getString(cursor.getColumnIndex("sCiudadCliente"));

                Registro registro = new Registro(idCliente, nombre, apellido, direccion, ciudad);
                registros.add(registro);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return registros;
    }

    private void eliminarRegistro(Registro registro) {
        // Eliminar el registro de la base de datos
        String whereClause = "id_cliente=?";
        String[] whereArgs = {String.valueOf(registro.getIdCliente())};
        database.delete("clientes", whereClause, whereArgs);
    }
}