package sv.edu.utec.parcial_4;

public class RegistroAdapter {
}
